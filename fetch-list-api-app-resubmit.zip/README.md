# Fetch and Display List from an API – React Mini Project

This is a mini project built using React. It fetches a list of posts from a public API (JSONPlaceholder) and displays them in a clean, styled interface.

## Features

✅ Fetches data using Fetch API  
✅ Uses `useState` and `useEffect` hooks  
✅ Displays loading and error states  
✅ Modular `ListComponent` for reusability  
✅ Semantic HTML (`<ul>`, `<li>`) and clean CSS

## How to Run Locally

1. Clone this repository:
   ```
   git clone https://github.com/Danmanya4710/fetch-list-api-app.git
   ```

2. Navigate into the folder:
   ```
   cd fetch-list-api-app
   ```

3. Install dependencies:
   ```
   npm install
   ```

4. Start the app:
   ```
   npm start
   ```

---

## Demo

Live demo: [https://your-netlify-site.netlify.app](https://your-netlify-site.netlify.app)

---

## Author

**Hussain Yahaya**  
Fellow ID: FE/23/36862511  
3MTT Software Development Specialization
